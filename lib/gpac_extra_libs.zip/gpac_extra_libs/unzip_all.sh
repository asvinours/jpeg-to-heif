#!/bin/sh

unzip "*.zip"
